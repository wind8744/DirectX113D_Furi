#include "pch.h"
#include "CPlayerScript.h"

#include <Engine\CSceneMgr.h>
#include <Engine\CScene.h>
#include <Engine/CCore.h>
#include <Engine\CRenderMgr.h>
#include <Engine\CCamera.h>
#include <Engine\CAnimator3D.h>
#include <Engine\CResMgr.h>
#include <Engine\CPrefab.h>
#include <Engine\CCollider2D.h>
#include <Engine\CGameObject.h>

#include "CMissileScript.h"
#include "CAnimatorScript.h"
#include "AnimNameList.h"
#include "CNavMeshManager.h"
#include "CCameraAnimaitorScript.h"
#include "CLawScript.h"
const float ChargefullTime = 1.f;

CPlayerScript::CPlayerScript()
	: CScript((int)SCRIPT_TYPE::PLAYERSCRIPT)
	, m_CurrentCombo(0)
	, m_PreCombo(0)
	, m_MaxCombo(4)
	, m_IsAttacking(false)
	, m_CanNextCombo(false)
	, m_IsComboInputOn(false)
	, m_fPlayerSpeed(400.f)
	, m_fAtime(0.f)
	, m_fMaxtime(0.5f)
	, m_Animation(nullptr)
	, m_Combo4AttackCase(0)
	, m_AnimDir(DIR::NONE)
	, m_PreAinmDir(DIR::NONE)
	, m_eCurDir(DIR::UP)
	, m_ePreDir(DIR::UP)
	, m_eCurState(PLAYER_STATE::IDLE)
	, m_ePrevState(PLAYER_STATE::IDLE)
	, m_Combo4AttackOn(false)
	, m_AttackDir(0.f, 0.f)
	, m_AttackSpeed(0.f)
	, m_AttackCharge(false)
	, m_AttackChargeTime(0.f)
	, m_AttackChargefull(false)
	, m_DashChargeTime(0.3f)
	, m_ParryTime(0.f)
	, m_GunAttackTime(0.f)
	, m_AttackMoveStop(false)
	, m_Target(nullptr)
	, m_hit(false)
	, m_vhitDir(Vec2(0.f, 0.f))
	, m_NavMeshManager(nullptr)
	, m_NavNum(0)
	, m_MeleeAtkOn(false)
	, m_CameraAnim(nullptr)
	, m_fHP(100.f)
	, m_iLife(5)
	, m_AttackMiss(false)
	, m_Grap(false)
	, m_GrapSolve(0)
	, m_HitSpeed(0.f)
	, m_Collignore(false)
	, m_fKnockDownTime(0.f)
	, m_bKnockdown(false)
	, m_TargetAngle(0.f)
	, m_GrapTime(0.f)
	, m_CPrePos(Vec3(0.f,0.f,0.f))
	, m_CloseBattle(true)
{
	m_tRay.vDir=Vec3(0.f, -1.f, 0.f);
	m_tRay.vDir.Normalize();
}

CPlayerScript::~CPlayerScript()
{
	
}

void CPlayerScript::awake()
{
	for (UINT i = 0; i < GetGameObject()->GetChild().size(); i++)
	{
		if (GetGameObject()->GetChild()[i]->Animator3D() != nullptr)
		{
			m_Animation = GetGameObject()->GetChild()[i]->Animator3D();
			break;
		}
	}
	m_Attack = CResMgr::GetInst()->FindRes<CPrefab>(L"PlayerAttack");

	assert(m_Animation);
	m_CameraAnim = (CCameraAnimaitorScript*)CSceneMgr::GetInst()->GetCurScene()->FindObjectByName(L"Camera_bn")->GetScript(L"CCameraAnimaitorScript");
	m_CameraAnim->SetTargerPlayer(GetGameObject());

	m_Target = CSceneMgr::GetInst()->GetCurScene()->FindObjectByName(L"Law");
	if (m_Target == nullptr)
		m_Target = CSceneMgr::GetInst()->GetCurScene()->FindObjectByName(L"Wise");
}

void CPlayerScript::update()
{
		//Ű �Է� ����

	CalRay();

	Vec3 _MonPos = Transform()->GetLocalPos();
	_MonPos.x = m_Target->Transform()->GetLocalPos().x - _MonPos.x;
	_MonPos.z = m_Target->Transform()->GetLocalPos().z - _MonPos.z;
	_MonPos.Normalize();
	m_TargetAngle = atan2f(_MonPos.x, _MonPos.z);
	
	CheckState();

	
	//���� ���¿� �´� �ִϸ��̼� ���
	PlayAnimation();


	//�ٲ� ���¿��� ������
	PlayerAction();


	Attack();


	m_PreCombo = m_CurrentCombo;


	if (KEY_TAP((KEY_TYPE::KEY_Z)))
		Grap();
	//if (KEY_TAP((KEY_TYPE::NUM_1)))
	//	KnockBack(Vec3(300.f, 0.f, 0.f), false, HitScale::HitLight, 0);
	if (KEY_TAP((KEY_TYPE::NUM_2)))
		KnockBack(Vec3(0.f, 0.f, -300.f), false, HitScale::HitLight, 0);
	if (KEY_TAP((KEY_TYPE::NUM_3)))
		KnockBack(Vec3(-300.f, 0.f, 0.f), false, HitScale::HitLight, 0);
}

void CPlayerScript::CheckState()
{

	m_ePrevState = m_eCurState;
	m_ePreDir = m_eCurDir;
	m_PreAinmDir = m_AnimDir;

	bool finish = m_Animation->GetFinish();
	float Ratio = m_Animation->GetAnimFrmRatio();
	if (Ratio >0.6f && m_eCurState == PLAYER_STATE::SWORDATTACK && m_Combo4AttackOn==false)
	{
		if (m_CurrentCombo == m_MaxCombo)
		{
			AttackEndComboState();
		}
		else if (m_IsComboInputOn)
		{
			AttackStartComboState();
		}
		else if (!m_IsComboInputOn)
		{
			m_fAtime += fDT;
			if (m_fMaxtime < m_fAtime)
			{
				AttackEndComboState();
				m_fAtime = 0.f;
			}
		}

	}
	if (m_MeleeAtkOn)
	{
		m_CameraAnim->SetCameraAnim(37);
		m_eCurState = PLAYER_STATE::MELEEATTACK;
		m_MeleeAtkOn = false;
	}
	if (m_AttackMiss)
	{
		//m_CameraAnim->SetCameraAnim(37);
		m_eCurState = PLAYER_STATE::SWORDATTACKMISS;
		m_AttackMiss = false;
	}
	if (m_Grap) {
		m_eCurState = PLAYER_STATE::GRAP;
		m_CameraAnim->SetCameraAnim(28);
		m_Grap = false;
	}
	if (m_eCurState == PLAYER_STATE::GRAP)
	{
		
		if (KEY_TAP(KEY_TYPE::KEY_A) || (KEY_TAP(KEY_TYPE::KEY_D)))
			m_GrapSolve++;

		if(m_GrapSolve >15)
		{
			m_eCurState = PLAYER_STATE::GRAPSOLVESUCCESS;
			m_CameraAnim->SetCameraAnim(29);
			m_GrapSolve = 0;
			CLawScript* Law = (CLawScript*)m_Target->GetScript(L"CLawScript");
			Law->SetPlayerGuardSucc();

		}
		if (finish)
		{
			m_eCurState = PLAYER_STATE::GRAPSOLVEFAILURE;
			m_CameraAnim->SetCameraAnim(30);
			m_GrapSolve = 0;
			CLawScript* Law = (CLawScript*)m_Target->GetScript(L"CLawScript");
			Law->SetPlayerGuardFail();
			
		}
	}
	if (m_eCurState == PLAYER_STATE::GRAPSOLVEFAILURE)
	{
		if (finish)
		{
			m_GrapTime += fDT;
			if (m_GrapTime > 0.5f) {
				m_GrapTime = 0.f;
				m_eCurState = PLAYER_STATE::IDLE;

				AttackEndComboState();
				m_Collignore = false;
			}
		}
	}
	if (m_eCurState == PLAYER_STATE::GRAPSOLVESUCCESS)
	{
		if (finish)
		{
			m_GrapTime += fDT;
			if (m_GrapTime > 0.5f) {
				m_GrapTime = 0.f;
				m_eCurState = PLAYER_STATE::IDLE;
				
				AttackEndComboState();
				m_Collignore = false;
			}
		}
		
	}
	if (finish && m_eCurState == PLAYER_STATE::MELEEATTACK)
	{
		m_eCurState = PLAYER_STATE::IDLE;
	}
	
	if (finish && m_eCurState == PLAYER_STATE::SWORDATTACKMISS)
	{
		m_eCurState = PLAYER_STATE::IDLE;
	}
	
	if (m_hit)
	{

		if (finish)
		{
			m_fKnockDownTime += fDT;
			if (m_fKnockDownTime >0.25f || !m_bKnockdown) {
				m_fKnockDownTime = 0.f;
				m_hit = false;
				int a = 0;
				UINT ret = m_Animation->MeshRender()->GetMtrlCount();
				for (int i = 0; i < ret; i++)
				{
					m_Animation->MeshRender()->GetSharedMaterial(i)->SetData(SHADER_PARAM::INT_3, &a);
				}
				AttackEndComboState();
				m_Collignore = false;
			}
		}
	
		
	}

	if ((m_eCurState == PLAYER_STATE::SWORDCHAGERATTACK || m_eCurState == PLAYER_STATE::GUNCHAGERATTACK) &&  Ratio>0.5f )
	{
		m_AttackSpeed = 0.f;
		if (finish)
		{
			m_eCurState = PLAYER_STATE::IDLE;
			AttackEndComboState();
		}
	}

	if (m_eCurState == PLAYER_STATE::DASH && finish)
	{
		m_DashChargeTime = 0.3f;
		m_eCurState = PLAYER_STATE::IDLE;
		m_Collignore = false;
	}

	if (m_eCurState == PLAYER_STATE::PARRYING)
	{
		m_ParryTime += fDT;
		if (m_ParryTime > 0.5f)
		{
			m_ParryTime = 0.f;
			m_eCurState = PLAYER_STATE::PARRYEND;
		}
	}
	if (m_eCurState == PLAYER_STATE::PARRYEND && finish)
	{
		m_eCurState = PLAYER_STATE::IDLE;
	}
	if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE || m_eCurState == PLAYER_STATE::SWORDATTACK || 
		m_eCurState == PLAYER_STATE::GUNATTACK || m_eCurState == PLAYER_STATE::SWORDCHAGER || m_eCurState == PLAYER_STATE::GUNCHAGER
		|| m_eCurState == PLAYER_STATE::DASHCHAGER)
	{
		if (KEY_HOLD(KEY_TYPE::KEY_W))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::UP;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_S))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::DOWN;

		}
		if (KEY_HOLD(KEY_TYPE::KEY_A))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::LEFT;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_D))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::RIGHT;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_W) && KEY_HOLD(KEY_TYPE::KEY_A))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::UPLEFT;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_W) && KEY_HOLD(KEY_TYPE::KEY_D))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::UPRIGHT;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_S) && KEY_HOLD(KEY_TYPE::KEY_A))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::DOWNLEFT;
		}
		if (KEY_HOLD(KEY_TYPE::KEY_S) && KEY_HOLD(KEY_TYPE::KEY_D))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE)
				m_eCurState = PLAYER_STATE::MOVE;
			m_eCurDir = DIR::DOWNRIGHT;
		}
		if (KEY_NONE(KEY_TYPE::KEY_A) && KEY_NONE(KEY_TYPE::KEY_S) && KEY_NONE(KEY_TYPE::KEY_D) && KEY_NONE(KEY_TYPE::KEY_W))
		{
			m_eCurDir = DIR::NONE;
		}
		if (KEY_HOLD(KEY_TYPE::LBTN) && m_eCurState != PLAYER_STATE::SWORDATTACK)
		{
			if (m_AttackChargeTime > 0.2f)
			{
				m_AttackCharge = true;
				m_AttackSpeed = 2000.f;
				m_eCurState = PLAYER_STATE::SWORDCHAGER;
			}
			if (m_AttackChargeTime > ChargefullTime)
				m_AttackChargefull = true;
			m_AttackChargeTime += fDT;
			float Rot;
			if (m_CloseBattle)
				Rot = m_TargetAngle;
			else
				Rot = MouseRote();
			switch (m_eCurDir)
			{
			case DIR::UP:
			{
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::RIGHT;
				}
			}
			break;
			case DIR::DOWN:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::LEFT;
				}
				break;
			case DIR::RIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWN;
				}
				break;
			case DIR::LEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UP;
				}
				break;
			case DIR::UPRIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				break;
			case DIR::UPLEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				break;
			case DIR::DOWNRIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				break;
			case DIR::DOWNLEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				break;
			case DIR::NONE:
			{
				m_AnimDir = DIR::NONE;
			}
			break;
			}
		}

		if (KEY_AWAY(KEY_TYPE::LBTN))
		{
			m_AttackChargeTime = 0.f;
		
			if(!m_AttackCharge)
				Attacking();
			else
			{

				m_eCurState = PLAYER_STATE::SWORDCHAGERATTACK;
				m_AttackCharge = false;
			}
		}

		if (KEY_HOLD(KEY_TYPE::RBTN) || KEY_HOLD(KEY_TYPE::MIDDLEBTN))
		{
			if (m_eCurState == PLAYER_STATE::IDLE || m_eCurState == PLAYER_STATE::MOVE || m_eCurState == PLAYER_STATE::GUNATTACK
				|| m_eCurState == PLAYER_STATE::GUNCHAGER)
			{
				if (KEY_HOLD(KEY_TYPE::RBTN) && m_eCurState != PLAYER_STATE::GUNCHAGER)
				{
					m_eCurState = PLAYER_STATE::GUNATTACK;
					m_AttackSpeed = 300.f;
				}
				else if (KEY_HOLD(KEY_TYPE::MIDDLEBTN))
				{
					if (m_AttackChargeTime > ChargefullTime)
						m_AttackChargefull = true;
					m_AttackChargeTime += fDT;
					m_eCurState = PLAYER_STATE::GUNCHAGER;
					m_AttackSpeed = 200.f;
				}
			}
			float Rot =  MouseRote();
			
			switch (m_eCurDir)
			{
			case DIR::UP:
			{
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::RIGHT;
				}
			}
				break;
			case DIR::DOWN:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::LEFT;
				}
				break;
			case DIR::RIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UP;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWN;
				}
				break;
			case DIR::LEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::LEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWN;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::RIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UP;
				}
				break;
			case DIR::UPRIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				break;
			case DIR::UPLEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				break;
			case DIR::DOWNRIGHT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				break;
			case DIR::DOWNLEFT:
				if (Rot > -0.785f && Rot < 0.785f)
				{
					m_AnimDir = DIR::DOWNLEFT;
				}
				else if (Rot >= 0.785f && Rot < 2.355f)
				{
					m_AnimDir = DIR::DOWNRIGHT;
				}
				else if (Rot > 2.355f || Rot < -2.355f)
				{
					m_AnimDir = DIR::UPRIGHT;
				}
				else if (Rot > -2.355f && Rot < -0.785f)
				{
					m_AnimDir = DIR::UPLEFT;
				}
				break;
			case DIR::NONE:
			{
				m_AnimDir = DIR::NONE;
			}
				break;
			}
			
		
			
		}
		if(KEY_AWAY(KEY_TYPE::RBTN))
			m_eCurState = PLAYER_STATE::IDLE;
		if (KEY_AWAY(KEY_TYPE::MIDDLEBTN) && m_eCurState == PLAYER_STATE::GUNCHAGER)
		{
			m_eCurState = PLAYER_STATE::GUNCHAGERATTACK;
		
			m_AttackChargeTime = 0.f;
		}

		if (KEY_HOLD(KEY_TYPE::SPACE) && !m_IsAttacking)
		{
			//AttackEndComboState();
       		m_eCurState = PLAYER_STATE::DASHCHAGER;
			MouseRote();
			m_DashChargeTime += fDT;
			if (m_DashChargeTime > 1.f)
				m_DashChargeTime = 1.f;
		}
		if (KEY_AWAY(KEY_TYPE::SPACE) && !m_IsAttacking)
		{
			m_eCurState = PLAYER_STATE::DASH;

		}
		if (KEY_TAP(KEY_TYPE::KEY_F) && m_eCurState != PLAYER_STATE::PARRYING)
		{
			m_eCurState = PLAYER_STATE::PARRYING;
			if (m_Target != nullptr) {
				
				Transform()->SetLocalRot(Vec3(0, m_TargetAngle, 0));
			}
		}
		if (KEY_NONE(KEY_TYPE::KEY_A) && KEY_NONE(KEY_TYPE::KEY_S) && KEY_NONE(KEY_TYPE::KEY_D) && KEY_NONE(KEY_TYPE::KEY_W) 
			&& KEY_NONE(KEY_TYPE::RBTN) && KEY_NONE(KEY_TYPE::LBTN) 
			&&(m_eCurState != PLAYER_STATE::SWORDATTACK) && KEY_NONE(KEY_TYPE::MIDDLEBTN)
			&& KEY_NONE(KEY_TYPE::SPACE) && KEY_NONE(KEY_TYPE::KEY_F)
			)
		{
			m_AttackSpeed = 400.f;
			m_eCurState = PLAYER_STATE::IDLE;
		}
	}
	
	if(m_eCurState == PLAYER_STATE::SWORDATTACK)
	{
		if(m_Combo4AttackOn)
		{ 
			if (m_Combo4AttackCase < 2)
				m_AttackSpeed = 1200.f;
			else
				m_AttackSpeed = 200.f;
		}
		else
		{
			if (Ratio > 0.5)
				m_AttackSpeed = 300.f;
			else
			{
				m_AttackSpeed = 1200.f;
			}
		}
	}
	if (m_eCurState == PLAYER_STATE::PARRYING)
	{
		m_AttackSpeed = 0.f;
	}
	if (m_CloseBattle && m_eCurState == PLAYER_STATE::MOVE)
	{
		switch (m_eCurDir)
		{
		case DIR::UP:
		{
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::UP;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::LEFT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::DOWN;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::RIGHT;
			}
		}
		break;
		case DIR::DOWN:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::DOWN;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::RIGHT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::UP;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::LEFT;
			}
			break;
		case DIR::RIGHT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::RIGHT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::UP;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::LEFT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::DOWN;
			}
			break;
		case DIR::LEFT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::LEFT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::DOWN;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::RIGHT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::UP;
			}
			break;
		case DIR::UPRIGHT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::UPRIGHT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::UPLEFT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::DOWNLEFT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::DOWNRIGHT;
			}
			break;
		case DIR::UPLEFT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::UPLEFT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::DOWNLEFT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::DOWNRIGHT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::UPRIGHT;
			}
			break;
		case DIR::DOWNRIGHT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::DOWNRIGHT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::UPRIGHT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::UPLEFT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::DOWNLEFT;
			}
			break;
		case DIR::DOWNLEFT:
			if (m_TargetAngle > -0.785f && m_TargetAngle < 0.785f)
			{
				m_AnimDir = DIR::DOWNLEFT;
			}
			else if (m_TargetAngle >= 0.785f && m_TargetAngle < 2.355f)
			{
				m_AnimDir = DIR::DOWNRIGHT;
			}
			else if (m_TargetAngle > 2.355f || m_TargetAngle < -2.355f)
			{
				m_AnimDir = DIR::UPRIGHT;
			}
			else if (m_TargetAngle > -2.355f && m_TargetAngle < -0.785f)
			{
				m_AnimDir = DIR::UPLEFT;
			}
			break;
		case DIR::NONE:
		{
			m_AnimDir = DIR::NONE;
		}
		break;
		}


		Transform()->SetLocalRot(Vec3(0, m_TargetAngle, 0));
	}

}

void CPlayerScript::PlayAnimation()
{
	if (m_ePrevState != m_eCurState || m_PreAinmDir != m_AnimDir)
	{
		if (PLAYER_STATE::MOVE == m_eCurState)
		{
			if (m_CloseBattle)
			{

				


				switch (m_AnimDir)
				{
				case DIR::UP:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalk3m));
					break;
				case DIR::DOWN:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalkBack3m));
					break;
				case DIR::RIGHT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockStrafeRight3m));
					break;
				case DIR::LEFT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockStrafeLeft3m));
					break;
				case DIR::UPRIGHT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalkStrafeRight3m));
					break;
				case DIR::UPLEFT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalkStrafeLeft3m));
					break;
				case DIR::DOWNRIGHT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalkBackStrafeRight3m));
					break;
				case DIR::DOWNLEFT:
					m_Animation->ChangeClip(UINT(MC_PLAYER::swordLockWalkBackStrafeLeft3m));
					break;
				case DIR::NONE:
					m_Animation->ChangeClip(UINT(MC_PLAYER::SwordIdle));
					break;
				}
			}
			else
			m_Animation->ChangeClip(UINT(MC_PLAYER::run12m));

		}
		else if (PLAYER_STATE::IDLE == m_eCurState)
		{
			if (m_CloseBattle)
			{
				m_Animation->ChangeClip(UINT(MC_PLAYER::SwordIdle));
				Transform()->SetLocalRot(Vec3(0, m_TargetAngle, 0));
			}
			else
			m_Animation->ChangeClip(UINT(MC_PLAYER::idle));
		}
		else if (PLAYER_STATE::SWORDATTACK == m_eCurState && m_CurrentCombo != 0)
		{
			
				switch (m_CurrentCombo)
				{
				case 1:
					m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK1), false);
					break;
				case 2:
					m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK2), false);
					break;
				case 3:
					m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK3), false);
					break;
				case 4:
					m_Combo4AttackOn = true;
					break;
				}
		
		}
		else if (PLAYER_STATE::GUNATTACK== m_eCurState)
		{
			switch (m_AnimDir)
			{
			case DIR::UP:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalk3m));
				break;
			case DIR::DOWN:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBack3m));
				break;
			case DIR::RIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimStrafeRight3m));
				break;
			case DIR::LEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimStrafeLeft3m));
				break;
			case DIR::UPRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkStrafeRight3m));
				break;
			case DIR::UPLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkStrafeLeft3m));
				break;
			case DIR::DOWNRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBackStrafeRight3m));
				break;
			case DIR::DOWNLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBackStrafeLeft3m));
				break;
			case DIR::NONE:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAim));
				break;
			}
		}
		else if (PLAYER_STATE::SWORDCHAGER == m_eCurState)
		{
			switch (m_AnimDir)
			{
			case DIR::UP:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalk2m));
				break;
			case DIR::DOWN:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalkBack2m));
				break;
			case DIR::RIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeStrafeRight2m));
				break;
			case DIR::LEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeStrafeLeft2m));
				break;
			case DIR::UPRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalkStrafeRight2m));
				break;
			case DIR::UPLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalkBackStrafeLeft2m));
				break;
			case DIR::DOWNRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalkBackStrafeRight2m));
				break;
			case DIR::DOWNLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::swordChargeWalkBackStrafeLeft2m));
				break;
			case DIR::NONE:
				m_Animation->ChangeClip(UINT(MC_PLAYER::SwordCharge));
				break;
			}
		}
		else if (PLAYER_STATE::SWORDCHAGERATTACK == m_eCurState)
		{
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordATK_Charged),false);
		}
		else if (PLAYER_STATE::GUNCHAGER == m_eCurState)
		{
			switch (m_AnimDir)
			{
			case DIR::UP:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalk1m));
				break;
			case DIR::DOWN:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBack1m));
				break;
			case DIR::RIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimStrafeRight1m));
				break;
			case DIR::LEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimStrafeLeft1m));
				break;
			case DIR::UPRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkStrafeRight1m));
				break;
			case DIR::UPLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkStrafeLeft1m));
				break;
			case DIR::DOWNRIGHT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBackStrafeRight1m));
				break;
			case DIR::DOWNLEFT:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunAimWalkBackStrafeLeft1m));
				break;
			case DIR::NONE:
				m_Animation->ChangeClip(UINT(MC_PLAYER::GunCharge));
				break;
			}
		}
		else if (PLAYER_STATE::GUNCHAGERATTACK == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::GunShot_Charged), false);
		}
		else if (PLAYER_STATE::DASHCHAGER == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::DodgeCharging));
		}
		else if (PLAYER_STATE::DASH == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::DodgeInstantGun));
		}
		else if (PLAYER_STATE::PARRYING == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::ParryIdle));
		}
		else if (PLAYER_STATE::PARRYEND == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::ParryEnd));
		}
		else if (PLAYER_STATE::SWORDATTACKMISS == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::swordParried), false);
		}
		else if (PLAYER_STATE::MELEEATTACK == m_eCurState)
		{
		if (m_Target->GetName() == L"Law")
			m_Animation->ChangeClip(UINT(MC_PLAYER::meleeAtkLaw_Stance1), false);
		else if (m_Target->GetName() == L"")
			m_Animation->ChangeClip(UINT(MC_PLAYER::meleeAtkWise_Stance2), false);
		}
		else if (PLAYER_STATE::GRAP == m_eCurState)
		{
		if (m_Target->GetName() == L"Law")
			m_Animation->ChangeClip(UINT(MC_PLAYER::grabLawStance1Charge1), false);
		}
		else if (PLAYER_STATE::GRAPSOLVESUCCESS == m_eCurState)
		{
		if (m_Target->GetName() == L"Law")
			m_Animation->ChangeClip(UINT(MC_PLAYER::grabLawStance1Charge1Success), false);
		}
		else if (PLAYER_STATE::GRAPSOLVEFAILURE == m_eCurState)
		{
		m_Animation->ChangeClip(UINT(MC_PLAYER::grabLawStance1Charge2), false);
		}
	}



	if (PLAYER_STATE::SWORDATTACK == m_eCurState && m_CurrentCombo != m_PreCombo && m_CurrentCombo != 0)
	{
		switch (m_CurrentCombo)
		{
		case 1:
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK1), false);
			break;
		case 2:
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK2), false);
			break;
		case 3:
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK3), false);
			break;
		case 4:
			m_Combo4AttackOn = true;
			break;
		}
	}
	if (m_Combo4AttackOn == true && m_eCurState ==PLAYER_STATE::SWORDATTACK)
	{
		switch (m_Combo4AttackCase)
		{
		case 0:
		{
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK4Start), false);
			m_Combo4AttackCase++;
		}
			break;
		case 1:
		{
			if (m_Animation->GetFinish())
				m_Combo4AttackCase++;
		}
		break;
		case 2:
		{
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK4Idle), false);
			Transform()->SetLocalPosY(100.f);
			m_Combo4AttackCase++;
		}
		break;
		case 3:
		{
			if (m_Animation->GetFinish())
				m_Combo4AttackCase++;

		}
		break;
		case 4:
		{
			m_Animation->ChangeClip(UINT(MC_PLAYER::SwordComboATK4End), false);
			Transform()->SetLocalPosY(0.f);
			m_Combo4AttackCase++;
		}
		break;
		case 5:
		{
			if (m_Animation->GetFinish())
			{
				m_Combo4AttackCase = 0;
				m_Combo4AttackOn = false;
			}
		}
		break;
		}
	}
}

void CPlayerScript::PlayerAction()
{
	Vec3 vPos = Transform()->GetLocalPos();
	Vec3 vRot = Transform()->GetLocalRot();

	if (m_hit)
	{
		vPos.x += -m_vhitDir.x * fDT * m_HitSpeed;
		vPos.z += -m_vhitDir.y * fDT * m_HitSpeed;
		Transform()->SetLocalPos(vPos);
		return;
	}

	if (m_eCurState == PLAYER_STATE::SWORDATTACK && !m_AttackMoveStop)
	{
		if (m_CloseBattle) {
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			vPos.x += TargetDir.x * fDT * m_AttackSpeed;
			vPos.z += TargetDir.z * fDT * m_AttackSpeed;
		}
		else
		{
			float CDistance = Vec3::Distance(m_Target->Transform()->GetLocalPos(), Transform()->GetLocalPos());
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			Vec3 AttackDir = Vec3(m_AttackDir.x, 0.f, m_AttackDir.y);
			float angle = AttackDir.Dot(TargetDir);
			if (angle < 0.f)
				angle = 6.28f - acosf(angle);
			else
				angle = acosf(angle);
			if (CDistance < 400 && angle < 0.52)
			{
				vPos.x += TargetDir.x * fDT * m_AttackSpeed;
				vPos.z += TargetDir.z * fDT * m_AttackSpeed;

			}
			else
			{
				vPos.x += m_AttackDir.x * fDT * m_AttackSpeed;
				vPos.z += m_AttackDir.y * fDT * m_AttackSpeed;
			}
		}
		Transform()->SetLocalPos(vPos);
	}

	else if (m_eCurState == PLAYER_STATE::SWORDCHAGERATTACK && !m_AttackMoveStop)
	{
		if (m_CloseBattle) {
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			vPos.x += TargetDir.x * fDT * m_AttackSpeed;
			vPos.z += TargetDir.z * fDT * m_AttackSpeed;
		}
		else
		{
			float CDistance = Vec3::Distance(m_Target->Transform()->GetLocalPos(), Transform()->GetLocalPos());
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			Vec3 AttackDir = Vec3(m_AttackDir.x, 0.f, m_AttackDir.y);
			float angle = AttackDir.Dot(TargetDir);
			if (angle < 0.f)
				angle = 6.28f - acosf(angle);
			else
				angle = acosf(angle);
			if (CDistance < 800 && angle < 0.26)
			{
				vPos.x += TargetDir.x * fDT * m_AttackSpeed;
				vPos.z += TargetDir.z * fDT * m_AttackSpeed;

			}
			else
			{
				vPos.x += m_AttackDir.x * fDT * m_AttackSpeed;
				vPos.z += m_AttackDir.y * fDT * m_AttackSpeed;
			}
		}
		Transform()->SetLocalPos(vPos);
	}

	if (m_eCurState == PLAYER_STATE::DASH)
	{
		m_Collignore = true;
		vPos.x += m_AttackDir.x * fDT * m_DashChargeTime * 4000.f;
		vPos.z += m_AttackDir.y * fDT * m_DashChargeTime * 4000.f;
		Transform()->SetLocalPos(vPos);
	}
	
	if (KEY_NONE(KEY_TYPE::KEY_W) && KEY_NONE(KEY_TYPE::KEY_S) && KEY_NONE(KEY_TYPE::KEY_A) && KEY_NONE(KEY_TYPE::KEY_D) || 
		m_eCurState == PLAYER_STATE::SWORDATTACK || m_eCurState == PLAYER_STATE::PARRYING || m_eCurState== PLAYER_STATE::DASHCHAGER
		|| m_eCurState == PLAYER_STATE::GUNCHAGERATTACK || m_eCurState == PLAYER_STATE::SWORDCHAGERATTACK
		)
		return;
//	CalRay();
	//if (!NavVectorCheck())
		//return;
	switch (m_eCurDir)
	{
	case DIR::UP:
	{
		vPos.z += fDT * m_fPlayerSpeed;//* CurCamera->Transform()->GetWorldDir(DIR_TYPE::FRONT);
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,0.f,0.f };
	}
	break;
	case DIR::DOWN:
	{
			vPos.z -= fDT * m_fPlayerSpeed;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,3.14f,0.f };
	}
	break;
	case DIR::LEFT:
	{
			vPos.x -= fDT * m_fPlayerSpeed;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,4.71f,0.f };
	}
	break;
	case DIR::RIGHT:
	{
			vPos.x += fDT * m_fPlayerSpeed;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,1.57f,0.f };
	}
	break;
	case DIR::DOWNLEFT:
	{
		
			vPos.z -= fDT * m_fPlayerSpeed / 1.4f;
			vPos.x -= fDT * m_fPlayerSpeed / 1.4f;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,3.925f,0.f };
	}
	break;
	case DIR::DOWNRIGHT:
	{
		
			vPos.z -= fDT * m_fPlayerSpeed / 1.4f;
			vPos.x += fDT * m_fPlayerSpeed / 1.4f;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,2.355f,0.f };
	}
	break;
	case DIR::UPLEFT:
	{
		
			vPos.z += fDT * m_fPlayerSpeed / 1.4f;
			vPos.x -= fDT * m_fPlayerSpeed / 1.4f;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,5.495f,0.f };
	}
	break;
	case DIR::UPRIGHT:
	{
	
			vPos.z += fDT * m_fPlayerSpeed / 1.4f;
			vPos.x += fDT * m_fPlayerSpeed / 1.4f;
			if (m_eCurState == PLAYER_STATE::MOVE && !m_CloseBattle)
			vRot = { 0.f,0.785f,0.f };
	}
	break;

	}
	Transform()->SetLocalPosX(vPos.x);
	Transform()->SetLocalPosZ(vPos.z);
	Transform()->SetLocalRot(vRot);
}

void CPlayerScript::Attacking()
{
	if (m_IsAttacking)
	{
		float n = m_Animation->GetAnimFrmRatio();
		if (m_CanNextCombo && 0.1 < n)
		{
			m_IsComboInputOn = true;
		}
	}
	else
	{
		AttackStartComboState();
		m_eCurState = PLAYER_STATE::SWORDATTACK;
		m_IsAttacking = true;
	}
}

void CPlayerScript::AttackStartComboState()
{
	if(!m_CloseBattle)
	MouseRote();


	m_CanNextCombo = true;
	m_IsComboInputOn = false;
	if (m_CurrentCombo + 1 > m_MaxCombo)
	{
		m_CurrentCombo = m_MaxCombo;
		
	}
	else if (m_CurrentCombo + 1 >= 1 && m_CurrentCombo + 1 <= m_MaxCombo)
	{
		m_CurrentCombo = m_CurrentCombo + 1;
	}
	else if (m_CurrentCombo + 1 < 1)
	{
		m_CurrentCombo = 1;
	}

}

void CPlayerScript::AttackEndComboState()
{
	m_IsAttacking = false;
	m_IsComboInputOn = false;
	m_CanNextCombo = false;
	m_CurrentCombo = 0;
	m_PreCombo = 0;
	m_eCurState = PLAYER_STATE::IDLE;
}

void CPlayerScript::MeleeAttack()
{
	AttackEndComboState();
	m_MeleeAtkOn = true;
	//m_eCurState = PLAYER_STATE::MELEEATTACK;
	
}

void CPlayerScript::Monsterguard()
{
	AttackEndComboState();
	m_AttackMiss = true;
	//m_eCurState = PLAYER_STATE::SWORDATTACKMISS;
	
}

void CPlayerScript::CalRay()
{
	m_tRay.vPoint = Transform()->GetLocalPos();
	switch (m_eCurDir)
	{
	case DIR::UP:
	{
		m_tRay.vPoint.z += fDT * m_fPlayerSpeed;//* CurCamera->Transform()->GetWorldDir(DIR_TYPE::FRONT);
		
	}
	break;
	case DIR::DOWN:
	{
		m_tRay.vPoint.z -= fDT * m_fPlayerSpeed;
	
	}
	break;
	case DIR::LEFT:
	{
		m_tRay.vPoint.x -= fDT * m_fPlayerSpeed;
		
	}
	break;
	case DIR::RIGHT:
	{
		m_tRay.vPoint.x += fDT * m_fPlayerSpeed;
	
	}
	break;
	case DIR::DOWNLEFT:
	{

		m_tRay.vPoint.z -= fDT * m_fPlayerSpeed / 1.4f;
		m_tRay.vPoint.x -= fDT * m_fPlayerSpeed / 1.4f;
		
	}
	break;
	case DIR::DOWNRIGHT:
	{

		m_tRay.vPoint.z -= fDT * m_fPlayerSpeed / 1.4f;
		m_tRay.vPoint.x += fDT * m_fPlayerSpeed / 1.4f;
	
	}
	break;
	case DIR::UPLEFT:
	{

		m_tRay.vPoint.z += fDT * m_fPlayerSpeed / 1.4f;
		m_tRay.vPoint.x -= fDT * m_fPlayerSpeed / 1.4f;
		
	}
	break;
	case DIR::UPRIGHT:
	{

		m_tRay.vPoint.z += fDT * m_fPlayerSpeed / 1.4f;
		m_tRay.vPoint.x += fDT * m_fPlayerSpeed / 1.4f;
		
	}
	break;
	}


}

bool CPlayerScript::PlayerNavCheck(Vec3 _vertices1, Vec3 _vertices2, Vec3 _vertices3, Vec3 _vStart, Vec3 _vDir)
{
	
	Vec3 edge[2] = { (Vec3)0.f, (Vec3)0.f };
	edge[0] = _vertices2 - _vertices1;
	edge[1] = _vertices3 - _vertices1;

	Vec3 normal = edge[0].Cross(edge[1]);
	normal.Normalize();
	float b = normal.Dot(_vDir);

	Vec3 w0 = _vStart - _vertices1;
	float a = normal.Dot(w0);
	float t = a / b;


	Vec3 p = _vStart + t * _vDir;
	float uu, uv, vv, wu, wv, inverseD;
	uu = edge[0].Dot(edge[0]);
	uv = edge[0].Dot(edge[1]);
	vv = edge[1].Dot(edge[1]);

	Vec3 w = p - _vertices1;
	wu = w.Dot(edge[0]);
	wv = w.Dot(edge[1]);
	inverseD = uv * uv - uu * vv;
	inverseD = 1.0f / inverseD;

	float u = (uv * wv - vv * wu) * inverseD;
	if (u < 0.0f || u > 1.0f)
	{
		return 0;
	}

	float v = (uv * wu - uu * wv) * inverseD;
	if (v < 0.0f || (u + v) > 1.0f)
	{
		return 0;
	}

	return 1;


}

void CPlayerScript::AllNavVectorCheck()
{
	vector<vector<NavMesh>*>* Nav =m_NavMeshManager->NavMeshVectorGet();
	
	for (UINT i = 0; i < Nav->size(); i++)
	{
		for (UINT l = 0; l < Nav->at(i)->size(); l++)
		{
			if (PlayerNavCheck(Nav->at(i)->at(l).fPointPos[0], Nav->at(i)->at(l).fPointPos[1], Nav->at(i)->at(l).fPointPos[2], m_tRay.vPoint, m_tRay.vDir))
			{
				m_NavVector = Nav->at(i);
				m_NavNum = l;
				break;
			}
		}
	}
}

bool CPlayerScript::NavVectorCheck()
{

		for (UINT l = 0; l < m_NavVector->size(); l++)
		{
			if (PlayerNavCheck(m_NavVector->at(l).fPointPos[0], m_NavVector->at(l).fPointPos[1], m_NavVector->at(l).fPointPos[2], m_tRay.vPoint, m_tRay.vDir))
			{
				m_NavNum = l;
				{
					float y = m_NavVector->at(l).fPointPos[0].y +
						m_NavVector->at(l).fPointPos[1].y +
						m_NavVector->at(l).fPointPos[2].y;
					
					y = (y / 3.f) + 30.f;
					Transform()->SetLocalPosY(y);
				}
				return true;
			}
		}
		return false;
}

bool CPlayerScript::NavCheck()
{
	for (UINT i = 0; i < m_NavVector->at(m_NavNum).vecAdjIdx.size(); i++)
	{
		if (PlayerNavCheck(m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[0],
			m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[1],
			m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[2], m_tRay.vPoint, m_tRay.vDir))
		{
			
			float y = m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[0].y +
				m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[1].y +
				m_NavVector->at(m_NavVector->at(m_NavNum).vecAdjIdx[i]).fPointPos[2].y;
			m_NavNum = m_NavVector->at(m_NavNum).vecAdjIdx[i];
			y = (y / 3.f) +30.f;
			Transform()->SetLocalPosY(y);
			return true;
		}
	}
	return false;
}

float CPlayerScript::MouseRote()
{

	tRay d =CurCamera->GetRay();
	Vec3 Pos = Transform()->GetLocalPos() - CurCamera->Transform()->GetWorldPos();
	Pos.Normalize();
	d.vDir.x -= Pos.x;
	d.vDir.z -= Pos.z;
	m_AttackDir.x = d.vDir.x;
	m_AttackDir.y = d.vDir.z;
	m_AttackDir.Normalize();
	float m_angle = atan2f(d.vDir.x, d.vDir.z);	//������ ����
	Transform()->SetLocalRot(Vec3(0, m_angle, 0));
	return m_angle;
}

bool CPlayerScript::KnockBack(Vec3 _CollPos,bool _Parrypossible, HitScale _HitScale, float _Damage)
{
	if (m_Collignore)
	{
		return false;
	}
	
	Vec3 _Pos = Transform()->GetLocalPos();
	m_vhitDir.x = _CollPos.x - _Pos.x;
	m_vhitDir.y = _CollPos.z - _Pos.z;
	m_vhitDir.Normalize();
	float m_TarAngle = atan2f(m_vhitDir.x, m_vhitDir.y);
	m_TarAngle = Transform()->GetLocalRot().y - m_TarAngle;
	
	if (m_eCurState == PLAYER_STATE::PARRYING && _Parrypossible)
	{
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitParrying1Light), false);
		
		return true;
	}
	else
	{
		m_bKnockdown = false;
		if(m_TarAngle >=0.f && m_TarAngle< 0.785f || m_TarAngle <0.f && m_TarAngle >=-0.785f)
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitReceived1Light),false, 2.0f);
		else if (m_TarAngle< -2.335f || m_TarAngle >=2.335f)
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitReceivedBack1Light), false, 2.0f);
		else if (m_TarAngle< -0.785f && m_TarAngle >=-2.335f)
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitReceivedLeft1Light), false, 2.0f);
		else if (m_TarAngle< 2.335f && m_TarAngle >=0.785f)
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitReceivedRight1Light), false, 2.0f);
		switch (_HitScale)
		{
		case HitScale::HitLight:
			m_HitSpeed = 100.f;
			break;
		case HitScale::HitMedium:
			m_HitSpeed = 200.f;
			break;
		case HitScale::HitBig:
			m_HitSpeed = 300.f;
			break;
			
		}
		m_hit = true;
		int a = 1;
		UINT ret = m_Animation->MeshRender()->GetMtrlCount();
		for (int i = 0; i < ret; i++)
		{
			m_Animation->MeshRender()->GetSharedMaterial(i)->SetData(SHADER_PARAM::INT_3, &a);
		}
		m_fHP -= _Damage;
		if (m_fHP <= 0)
		{
			m_iLife--;
			if (m_iLife > 0)
				m_fHP = 100.f;
		}
		m_eCurState = PLAYER_STATE::HIT;
		m_Collignore = true;
	}
	
	return false;
}

bool CPlayerScript::knockdown(Vec3 _CollPos,bool _Parrypossible, HitScale _HitScale, float _Damage)
{
	if (m_Collignore)
	{
		return false;
	}
	Vec3 _Pos = Transform()->GetLocalPos();
	m_vhitDir.x = _CollPos.x - _Pos.x;
	m_vhitDir.y = _CollPos.z - _Pos.z;
	m_vhitDir.Normalize();
	float m_TarAngle = atan2f(m_vhitDir.x, m_vhitDir.y);
	m_TarAngle = Transform()->GetLocalRot().y - m_TarAngle;

	if (m_eCurState == PLAYER_STATE::PARRYING && _Parrypossible)
	{
		m_Animation->ChangeClip(UINT(MC_PLAYER::hitParrying1Light), false);

		return true;
	}
	else
	{
		m_bKnockdown = true;
		if (m_TarAngle >= 0.f && m_TarAngle < 0.785f || m_TarAngle < 0.f && m_TarAngle >= -0.785f)
			m_Animation->ChangeClip(UINT(MC_PLAYER::hitKnockdown1Front1Light), false, 2.0f);
		else if (m_TarAngle < -2.335f || m_TarAngle >= 2.335f)
			m_Animation->ChangeClip(UINT(MC_PLAYER::hitKnockdown4Back1Light), false, 2.0f);
		else if (m_TarAngle < -0.785f && m_TarAngle >= -2.335f)
			m_Animation->ChangeClip(UINT(MC_PLAYER::hitKnockdown2Left1Light), false, 2.0f);
		else if (m_TarAngle < 2.335f && m_TarAngle >= 0.785f)
			m_Animation->ChangeClip(UINT(MC_PLAYER::hitKnockdown3Right1Light), false, 2.0f);
		switch (_HitScale)
		{
		case HitScale::HitLight:
			m_HitSpeed = 100.f;
			break;
		case HitScale::HitMedium:
			m_HitSpeed = 200.f;
			break;
		case HitScale::HitBig:
			m_HitSpeed = 300.f;
			break;

		}
		m_hit = true;
		int a = 1;
		UINT ret = m_Animation->MeshRender()->GetMtrlCount();
		for (int i = 0; i < ret; i++)
		{
			m_Animation->MeshRender()->GetSharedMaterial(i)->SetData(SHADER_PARAM::INT_3, &a);
		}
		m_eCurState = PLAYER_STATE::HIT;
			
		m_fHP -= _Damage;
		if (m_fHP <= 0)
		{
			m_iLife--;
			if (m_iLife > 0)
				m_fHP = 100.f;
		}
		m_Collignore = true;
	}
	
	return false;
}

bool CPlayerScript::Grap()
{
	if (PLAYER_STATE::PARRYING == m_eCurState)
	{
		return false;
	}
	else
	{
		m_Collignore = true;
		m_Grap = true;
		return true;
	}
}


void CPlayerScript::OnCollisionEnter(CGameObject* _pOther)
{


}

void CPlayerScript::OnCollisionExit(CGameObject* _pOther)
{
	if (_pOther->GetName() == L"Law" || _pOther->GetName() == L"Wise" || _pOther->GetName() == L"Pillar")
	{
		m_AttackMoveStop = false;
	}


	
}

void CPlayerScript::OnCollision(CGameObject* _pOther)
{
	if (_pOther->GetName() == L"Law" || _pOther->GetName() == L"Wise" || _pOther->GetName() == L"Pillar")
	{
		Vec2 C_Dir= _pOther->Collider2D()->GetPos() - Collider2D()->GetPos();
		C_Dir.Normalize();
		C_Dir *= _pOther->Collider2D()->GetScale();


		if (abs(C_Dir.x) > abs(_pOther->Collider2D()->GetPos().x - Collider2D()->GetPos().x))
		{
			if (_pOther->Collider2D()->GetPos().x > Collider2D()->GetPos().x )
			{
				float x = C_Dir.x - abs(_pOther->Collider2D()->GetPos().x - Collider2D()->GetPos().x);
				float asda = Transform()->GetLocalPos().x;
				x = Transform()->GetLocalPos().x - x;
				Transform()->SetLocalPosX(x);
			}
			else
			{
				float x = abs(C_Dir.x) - abs(_pOther->Collider2D()->GetPos().x - Collider2D()->GetPos().x);
				x = Transform()->GetLocalPos().x + x;
				Transform()->SetLocalPosX(x);
			}
		}
		if (abs(C_Dir.y) > abs(_pOther->Collider2D()->GetPos().y - Collider2D()->GetPos().y))
		{
			if (_pOther->Collider2D()->GetPos().y > Collider2D()->GetPos().y)
			{
				float y = C_Dir.y - abs(_pOther->Collider2D()->GetPos().y - Collider2D()->GetPos().y);
				y = Transform()->GetLocalPos().z - y;
				Transform()->SetLocalPosZ(y);
			}
			else
			{
				float y = abs(C_Dir.y)- abs(_pOther->Collider2D()->GetPos().y - Collider2D()->GetPos().y);
				y = Transform()->GetLocalPos().z + y;
				Transform()->SetLocalPosZ(y);
			}
		}
		m_AttackMoveStop = true;
	}
	
	if (_pOther->GetName() == L"c")
	{
		Vec2 C_Dir= Collider2D()->GetPos() -_pOther->Collider2D()->GetPos() ;
		float dis = Vec2::Distance(Collider2D()->GetPos(), _pOther->Collider2D()->GetPos());

		
		if (dis >= _pOther->Collider2D()->GetScale().x/2.f)
		{
			C_Dir.Normalize();
			float x = _pOther->Collider2D()->GetPos().x + C_Dir.x * _pOther->Collider2D()->GetScale().x/2.f;
			if(abs(Collider2D()->GetPos().x) >= abs(x)) ;
			{
				Transform()->SetLocalPosX(x);
			}
		}
	
		if (dis >= _pOther->Collider2D()->GetScale().y / 2.f)
		{
			C_Dir.Normalize();
			float y = _pOther->Collider2D()->GetPos().y + C_Dir.y * _pOther->Collider2D()->GetScale().y/2.f;
			if (abs(Collider2D()->GetPos().y) >= abs(y));
			{
				Transform()->SetLocalPosZ(y);
			}
		}

	}

}

void CPlayerScript::SaveToScene(FILE* _pFile)
{
	CScript::SaveToScene(_pFile);
}

void CPlayerScript::LoadFromScene(FILE* _pFile)
{
	CScript::LoadFromScene(_pFile);
}
