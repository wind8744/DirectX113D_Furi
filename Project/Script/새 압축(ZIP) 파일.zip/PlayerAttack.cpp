#include "pch.h"
#include "CPlayerScript.h"
#include <Engine\CEventMgr.h>
#include "CPlayerAttackScript.h"
void CPlayerScript::Attack() {

	if (m_CurrentCombo != m_PreCombo && m_CurrentCombo != 0 && PLAYER_STATE::SWORDATTACK == m_eCurState)
	{
		CGameObject* Attack = m_Attack->Instantiate();
		CPlayerAttackScript* AttackScript = (CPlayerAttackScript*)Attack->GetScript(L"CPlayerAttackScript");
		if (m_CloseBattle)
		{
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			Vec2 TargetDir2 = Vec2(TargetDir.x, TargetDir.z);
			AttackScript->SetPlayer(GetGameObject(), TargetDir2);
		}
		else
		AttackScript->SetPlayer(GetGameObject(), m_AttackDir);

		AttackScript->SetAttackType(Attack_Type::SowrdAttack);

		 tEvent even = {};
		 even.eEvent = EVENT_TYPE::CREATE_OBJECT;
		 even.lParam = (DWORD_PTR)Attack;
		 //even.wParam = (DWORD_PTR)GetGameObject()->GetLayerIndex();
		 even.wParam = (DWORD_PTR)1;
		 CEventMgr::GetInst()->AddEvent(even);
	}
	else if(PLAYER_STATE::SWORDCHAGERATTACK == m_eCurState && m_eCurState != m_ePrevState)
	{
		CGameObject* Attack = m_Attack->Instantiate();
		CPlayerAttackScript* AttackScript = (CPlayerAttackScript*)Attack->GetScript(L"CPlayerAttackScript");
		if (m_CloseBattle)
		{
			Vec3 TargetDir = m_Target->Transform()->GetLocalPos() - Transform()->GetLocalPos();
			TargetDir.Normalize();
			Vec2 TargetDir2 = Vec2(TargetDir.x, TargetDir.z);
			AttackScript->SetPlayer(GetGameObject(), TargetDir2);
		}
		else
		AttackScript->SetPlayer(GetGameObject(), m_AttackDir);
		
			if(m_AttackChargefull)
		AttackScript->SetAttackType(Attack_Type::FullChargeSowrdAttack);
		else
			AttackScript->SetAttackType(Attack_Type::ChargeSowrdAttack);

		tEvent even = {};
		even.eEvent = EVENT_TYPE::CREATE_OBJECT;
		even.lParam = (DWORD_PTR)Attack;
		//even.wParam = (DWORD_PTR)GetGameObject()->GetLayerIndex();
		even.wParam = (DWORD_PTR)1;
		CEventMgr::GetInst()->AddEvent(even);
	}
	else if (PLAYER_STATE::GUNATTACK == m_eCurState )
	{

		if (m_GunAttackTime > 0.5f)
		{
			m_GunAttackTime = 0.f;
			CGameObject * Attack = m_Attack->Instantiate();
			CPlayerAttackScript* AttackScript = (CPlayerAttackScript*)Attack->GetScript(L"CPlayerAttackScript");
			AttackScript->SetPlayer(GetGameObject(), m_AttackDir);
		
			AttackScript->SetAttackType(Attack_Type::GunAttack);


			tEvent even = {};
			even.eEvent = EVENT_TYPE::CREATE_OBJECT;
			even.lParam = (DWORD_PTR)Attack;
			//even.wParam = (DWORD_PTR)GetGameObject()->GetLayerIndex();
			even.wParam = (DWORD_PTR)3;
			CEventMgr::GetInst()->AddEvent(even);
		}
			m_GunAttackTime += fDT;
		
	}
	else if (PLAYER_STATE::GUNCHAGERATTACK == m_eCurState && m_eCurState != m_ePrevState)
	{
		CGameObject* Attack = m_Attack->Instantiate();
		CPlayerAttackScript* AttackScript = (CPlayerAttackScript*)Attack->GetScript(L"CPlayerAttackScript");
		AttackScript->SetPlayer(GetGameObject(), m_AttackDir);
		
		if (m_AttackChargefull)
			AttackScript->SetAttackType(Attack_Type::FullChargeGunAttack);
		else
			AttackScript->SetAttackType(Attack_Type::ChargeGunAttack);

		tEvent even = {};
		even.eEvent = EVENT_TYPE::CREATE_OBJECT;
		even.lParam = (DWORD_PTR)Attack;
		//even.wParam = (DWORD_PTR)GetGameObject()->GetLayerIndex();
		even.wParam = (DWORD_PTR)3;
		CEventMgr::GetInst()->AddEvent(even);
	}
}