#pragma once
#include <Engine\CScript.h>

class CAnimator3D;
class CNavMeshManager;
class CCameraAnimaitorScript;
enum class HitScale{
    HitLight,
    HitMedium,
    HitBig
};
class CPlayerScript :
    public CScript
{
private:
    PLAYER_STATE        m_eCurState;            //�÷��̾��� ���� ����
    PLAYER_STATE        m_ePrevState;           //���� ����

    DIR                 m_eCurDir;              //���� ����
    DIR                 m_ePreDir;              //���� ����
    DIR                 m_AnimDir;
    DIR                 m_PreAinmDir;

    float               m_fPlayerSpeed;         //�÷��̾� ���ǵ�
    float               m_fAtime;               //�����ð�
    float               m_fMaxtime;


    int                  m_CurrentCombo;
    int                  m_PreCombo;
    int                  m_MaxCombo;
    int                  m_Combo4AttackCase;


    bool                 m_IsAttacking;
    bool                 m_CanNextCombo;
    bool                 m_IsComboInputOn;
    bool                 m_Combo4AttackOn;
    bool                 m_AttackMoveStop;



    bool                 m_AttackCharge;
    float                m_AttackChargeTime;
    bool                 m_AttackChargefull;
     
    bool                m_MeleeAtkOn;
    bool                m_AttackMiss;
    bool                m_Grap;
  
    int                 m_GrapSolve;
    float               m_GrapTime;

    float               m_GunAttackTime;

    float                m_DashChargeTime;

    float                m_ParryTime;

    Vec2                 m_AttackDir;
    float                m_AttackSpeed;
    CAnimator3D*       m_Animation;

    Ptr<CPrefab>             m_Attack;


    CGameObject*            m_Target;
    float                   m_TargetAngle;
    CNavMeshManager*        m_NavMeshManager;
    vector<NavMesh>*        m_NavVector;
    UINT                 m_NavNum;
    bool                 m_hit;
    Vec2                 m_vhitDir;

    bool                 m_bKnockdown;
    float                m_fKnockDownTime;
    float                 m_HitSpeed;


    tRay                 m_tRay;

    float               m_fHP;
    UINT                m_iLife;
    CCameraAnimaitorScript* m_CameraAnim;

    bool                m_Collignore;

    Vec3                m_CPrePos;


    bool                m_CloseBattle;
public:
    virtual void awake();
    virtual void update();

public:
    void SetTarGetObj(CGameObject* _OBj) { m_Target = _OBj; }
    void SetNaviManager(CNavMeshManager* _OBj) { m_NavMeshManager = _OBj; }

    GET(float, TargetAngle);
    GET_SET(float, fHP);
    GET_SET(UINT, iLife);
private:
    void CheckState();
    void PlayAnimation();

    void PlayerAction();
    void Attack();
    void Attacking();
    void AttackStartComboState();
    void AttackEndComboState();

    
   
    void CalRay();
    bool PlayerNavCheck(Vec3 _vertices1, Vec3 _vertices2, Vec3 _vertices3, Vec3 _vStart, Vec3 _vDir);
    void AllNavVectorCheck();
    bool NavVectorCheck();
    bool NavCheck();
    float MouseRote();
    const tRay& GetRay() { return m_tRay; }

 
public:
    bool KnockBack(Vec3 _CollPos,bool _Parrypossible, HitScale _HitScale,float _Damage);
    bool knockdown(Vec3 __CollPos,bool _Parrypossible, HitScale _HitScale, float _Damage);
    GET_SET(bool, Collignore);
    bool Grap();
    void MeleeAttack();
    void Monsterguard();

    void SetCloseBattle(bool _CloseBattle) { m_CloseBattle = _CloseBattle; }
    CCameraAnimaitorScript* GetCameraAnimitor() { return m_CameraAnim; }
public:
    virtual void OnCollisionEnter(CGameObject* _pOther);
    virtual void OnCollisionExit(CGameObject* _pOther);
    virtual void OnCollision(CGameObject* _pOther);
public:
    CLONE(CPlayerScript);
    virtual void SaveToScene(FILE* _pFile);
    virtual void LoadFromScene(FILE* _pFile);


public:
    CPlayerScript();
    ~CPlayerScript();
};

